package com.dicoding.eventapp.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.eventapp.data.response.EventResponse
import com.dicoding.eventapp.data.retrofit.ApiConfig
import com.dicoding.eventapp.utils.Events
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _eventList = MutableLiveData<EventResponse>()
    val eventList: LiveData<EventResponse?> get() = _eventList

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    private val _snackBar = MutableLiveData<Events<String>>()
    val snackBar: LiveData<Events<String>> get() = _snackBar

    companion object {
        private const val TAG = "MainViewModel"
    }

    fun getActiveEvents() {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val response = ApiConfig.getApiService().getActiveEvents() // Memanggil API service untuk mendapatkan acara aktif
                _eventList.value = response // Mengupdate LiveData dengan daftar acara
            } catch (e: Exception) {
                _snackBar.value = Events("Terjadi kesalahan: ${e.message}")
                Log.e(TAG, "onFailure: ${e.message}")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getPastEvents() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = ApiConfig.getApiService().getPastEvents() // Panggil metode API
                _eventList.value = response // Atur hasil ke LiveData
            } catch (e: Exception) {
                // Tangani kesalahan
                _snackBar.value = Events("Terjadi kesalahan saat mengambil acara.")
            } finally {
                _isLoading.value = false
            }
        }
    }
}