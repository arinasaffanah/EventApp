package com.dicoding.eventapp.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.eventapp.data.response.ListEventsItem

class EventDetailViewModel : ViewModel() {
    private val _eventDetails = MutableLiveData<ListEventsItem?>()
    val eventDetails: LiveData<ListEventsItem?> get() = _eventDetails

    fun getEventDetails(eventId: String) {
        // Implementasi logika untuk mendapatkan detail acara berdasarkan ID
        // Misalnya, ambil data dari repository atau API
    }
}